
extern zend_class_entry *phalcon_mvc_micro_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Mvc_Micro_Exception);

