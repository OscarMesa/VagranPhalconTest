
extern zend_class_entry *phalcon_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Exception);

